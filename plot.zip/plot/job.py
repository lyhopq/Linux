#!/usr/bin/python
# coding=utf-8

import numpy as np
import matplotlib.pylab as plt


num = 5
#fracs = [100/num]*num
#explode = [0.02]*num
#labels = (u'编译', u'SM', u'PcLint', u'Test', u'Cover')
#plt.figure(1, figsize=(2,2))
#ax = plt.axes([0., 0., 1., 1.])
#ax.pie(fracs, labels=labels, labeldistance=0.6, startangle=90, radius=1.2)
##plt.show()
#plt.savefig('job.png', transparent=True)


plt.figure(1, figsize=(1.5,1.5), dpi=80)
center = np.array([0.5,0.5])
R = 0.35
ax = plt.axes([0., 0., 1., 1.], frameon=False)

circle = plt.Circle(center, R, facecolor='gray',
                edgecolor='blue', linewidth=1, alpha=1.0)
ax.add_patch(circle)
plt.text(center[0], center[1], u'13.06.10\n11:45:32', ha='center', va='center', color="black",
        transform=plt.gca().transAxes, fontsize=10, clip_on=True)

labels = (u'Build', u'SM', u'PcLint', u'Test', u'Cover')
for i in range(num):
    alpha = i*360/num*np.pi/180
    nextcenter = center + (R-0.02)*np.array([np.sin(alpha), np.cos(alpha)])
    circle = plt.Circle(nextcenter, 0.15, facecolor='lightgreen',
                        edgecolor='yellow', linewidth=2, alpha=1.0)
    ax.add_patch(circle)
    plt.text(nextcenter[0], nextcenter[1], labels[i], ha='center', va='center', color="red",
            transform=plt.gca().transAxes, fontsize=12, clip_on=True)

    print int(nextcenter[0]*150), int(150-nextcenter[1]*150),int(0.15*150)
    #if i == 0:
    #    aa = np.arange(0,20)*360/20*np.pi/180
    #    xmaps = (nextcenter[0] + 0.15*np.sin(aa))*150
    #    ymaps = (nextcenter[1] + 0.15*np.cos(aa))*150

    #    print xmaps.astype(np.int)
    #    print ymaps.astype(np.int)



#plt.show()
plt.xticks(())
plt.yticks(())
plt.savefig('job.png', transparent=True)
