typedef char BYTE;

typedef struct tag_structB
{
    char a;
    int b;
    BYTE c;
    int d:8;
    union
    {
        char e;
        int f;
    };
} structB;

typedef struct tag_structA
{
    int a;
    char b[1000];
    char *c;
    structB d;
    structB e[10];
    BYTE *f;
    structB *g;
} structA;

void main()
{
    structA ss;
}
