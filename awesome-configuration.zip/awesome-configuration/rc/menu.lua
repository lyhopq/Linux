-- {{{ Menu
-- Create a laucher widget and a main menu
myawesomemenu = {
   { "manual", config.terminal .. " -e man awesome" },
   { "edit config", config.editor_cmd .. " " .. awesome.conffile },
   { "restart", awesome.restart },
   { "quit", awesome.quit }
}

mymainmenu = awful.menu({ items = { { "awesome", myawesomemenu, beautiful.awesome_icon },
                                    { "Debian", debian.menu.Debian_menu.Debian },
                                    { "open terminal", config.terminal }
                                  }
                        })

mylauncher = awful.widget.launcher({ image = image(beautiful.awesome_icon),
                                     menu = mymainmenu })
-- }}}

--myawesomemenu = {
--   { "lock", "xscreensaver-command -activate" },
--   { "manual", config.terminal .. " -e man awesome" },
--   { "edit config", config.editor_cmd .. " " .. awful.util.getdir("config") .. "/rc.lua" },
--   { "restart", awesome.restart },
--   { "quit", awesome.quit }
--}
--
--mycommons = {
--   { "pidgin", "pidgin" },
--   { "OpenOffice", "soffice-dev" },
--   { "Graphic", "gimp" }
--}

--mymainmenu = awful.menu.new({ items = { 
--                                        { "terminal", terminal },
--                                        { "icecat", "icecat" },
--                                        { "Editor", "gvim" },
--                                        { "File Manager", "pcmanfm" },
--                                        { "VirtualBox", "VirtualBox" },
--                                        { "Common App", mycommons, beautiful.awesome_icon },
--                                        { "awesome", myawesomemenu, beautiful.awesome_icon }
--                                       }
--                             })
--

config.keys.global = awful.util.table.join(
   config.keys.global,
   awful.key({modkey, }, "w", function() mymainmenu:show({keygrabber=true}) end))
