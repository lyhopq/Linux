-- Lockscreen

local icons = loadrc("icons", "vbe/icons")

xrun("xautolock",
     awful.util.getdir("config") ..
        "/bin/xautolock " ..
        awful.util.getdir("config") .. "/icons/lyh.png")

config.keys.global = awful.util.table.join(
   config.keys.global,
   awful.key({modkey, "Control" }, "l", function() awful.util.spawn("xautolock -locknow", false) end))

-- Configure DPMS
os.execute("xset dpms 360 720 1200")
